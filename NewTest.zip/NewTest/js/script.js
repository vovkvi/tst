let keys = [];

$(document).ready(() => {
    $('title').text(`Тестирование: ${test_id}`)
    $('.test-title').text(test_title);
    $.each(data, (idx,obj) => {
        obj.o = shuffle(obj.o);
        $("main").append(AddQuestion(idx,obj));
    });
    AddButtonSection();
});

function shuffle(array) {
    let currentIndex = array.length, randomIndex;
    while (currentIndex > 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
    return array;
}

function checkAnswers(event) {
    let result = [];
    $.each($("section.question"), (i,o) => {
        let s = "";
        $.each(o.getElementsByClassName("option"), (i,e) => {
            s += e.checked ? 1 : 0;
            e.setAttribute('disabled', true);
        });
        if (s == keys[i]) {
            o.style.background = 'var(--test-pass-color)';
        } else {
            o.style.background = 'var(--test-fail-color)';
        }
        result.push(s);
    });

    let ok = 0;
    $.each(keys, (i,o) => {
        if (o == result[i])
            ok++;
    });
    $('.test-limit').text(test_limit);
    $('.test-status').text(ok >= test_limit ? 'пройден' : 'не пройден');
    $('.test-status').css('color', ok >= test_limit ? 'green' : 'red');
    $('.test-statictic').text(`Правильных ответов: ${ok} из ${keys.length}`);
    toggleModal(event);
}

function resetTest(event) {
    window.scrollTo(0,0);
    location.reload();
}

function AddButtonSection() {
    let div = Object.assign(document.createElement("div"), {
        id: 'button-bar',
        className: "buttons"
    });
    let button = Object.assign(document.createElement("button"), {
        className: "primary",
        innerHTML: 'Завершить тестирование'
    });
    button.setAttribute('data-target', 'modal-example');
    button.setAttribute('onclick', 'checkAnswers(event)');
    div.append(button);
    $("main").append(div);
}

function AddQuestion(idx,object) {
    let section =  Object.assign(document.createElement("section"), {
        id: idx,
        className: "question"
    });
    let h3 =  Object.assign(document.createElement("h3"), {
        innerHTML: `${idx+1}. ${object.h}`
    });
    let optarr = "";
    let answcnt = 0;
    $.each(object.o, (i,v) => {
        if (v[0] == '*') {
            answcnt++;
            optarr += 1;
        } else {
            optarr += 0;
        }
    });
    keys.push(optarr);
    let input_type = answcnt > 1 ? "checkbox" : "radio";
    let fieldset = document.createElement("fieldset");
    $.each(object.o, (i,v) => {
        let label = Object.assign(document.createElement("label"), {
            for: `q${idx}-${i}`
        });
        label.append(
            Object.assign(document.createElement("input"), {
                className: 'option',
                type: input_type,
                name: `${input_type}${idx}`,
                id: `q${idx}-${i}`
            }),
            v.charAt(0) === '*' ? v.slice(1) : v
        );
        fieldset.append(label);
    });
    section.append(h3, fieldset);
    return section;
}
