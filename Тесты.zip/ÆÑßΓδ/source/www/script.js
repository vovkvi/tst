
//let pageConfig;
let keys = [];
// async function fetchConfig() {
//     try {
//         const response = await fetch('./data.json');
//         let data = await response.json();
//         pageConfig = data.description;
//     } catch(e) {
//         console.error(`[fetchConfig] code: ${e.status}; message: ${e}`);
//     }
// }

$(document).ready(() => {
    $.each(data, (idx,obj) => {
        obj.o = shuffle(obj.o);
        $("main").append(AddQuestion(idx,obj));
        AddQuestionInNavList(idx);
    });
    AddButtonSection();
});

function AddQuestionInNavList(idx) {
    let li = Object.assign(document.createElement('li'), {
        innerHTML: `<a href="#question${idx+1}"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-feather"><use xlink:href="#qi"></use></svg>Вопрос №${idx+1}</a>`
    });
    $(".section-list").append(li);
}

function shuffle(array) {
    let currentIndex = array.length, randomIndex;
    while (currentIndex > 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        [array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]];
    }
    return array;
}

// function compileFile() {
//     let user = document.getElementById("username").value;
//     let group = document.getElementById("usergroup").value;
//     let result = `${user}\n${group}\n`;
//     $.each($("section.question"), (i,o) => {
//         var s = `${i}=`;
//         $.each(o.getElementsByClassName("option"), (i,e) => {
//             s += e.checked ? 1 : 0;
//         });
//         result += `${s}\n`;
//     });
//     downloadTextFile(user, result);
// }

// function downloadTextFile(name, text) {
//     var tmpTag = document.createElement('a');
//     var file = new Blob([text], {type: 'text/plain'});
//     tmpTag.href = URL.createObjectURL(file);
//     tmpTag.download = `${name}.txt`;
//     tmpTag.click()
// }

function checkAnswers() {
    let result = [];
    $.each($("section.question"), (i,o) => {
        let s = "";
        $.each(o.getElementsByClassName("option"), (i,e) => {
            s += e.checked ? 1 : 0;
        });
        if (s == keys[i]) {
            o.style.background = '#B2FF59';
        } else {
            o.style.background = '#FFAB91';
        }
        result.push(s);
    });

    let ok = 0;
    $.each(keys, (i,o) => {
        if (o == result[i])
            ok++;
    });
    console.log($("#rt-val"));
    $("#rt-val").text(`Результат: ${ok} из ${keys.length}`);
}

function AddButtonSection() {
    let div = Object.assign(document.createElement("div"), {
        id: 'button-bar',
        className: "to-reset",
        innerHTML: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-power"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>Завершить тестирование'
    });
    div.setAttribute('onclick', 'checkAnswers();');

    let section = document.createElement("section");
    section.append(
        Object.assign(document.createElement("div"), {
            className: "result-text",
            innerHTML: `<h2 id="rt-val">Результат: 0 из ${keys.length}</h2>`
        }),
        div
    );

    $("main").append(section);
}

function AddQuestion(idx,object) {

    let section =  Object.assign(document.createElement("section"), {
        id: idx,
        className: "question"
    });
    let div = Object.assign(document.createElement("div"), {
        className: "href-target",
        id: `question${idx+1}`
    });
    let h2 =  Object.assign(document.createElement("h2"), {
        innerHTML: `${idx+1}. ${object.h}`
    });
    let fieldset = Object.assign(document.createElement("fieldset"), {
        className: "nice-form-group"
    });

    let optarr = "";
    let answcnt = 0;
    $.each(object.o, (i,v) => {
        if (v[0] == '*') {
            answcnt++;
            optarr += 1;
        } else {
            optarr += 0;
        }
    });
    keys.push(optarr);

    let input_type = answcnt > 1 ? "checkbox" : "radio";

    $.each(object.o, (i,v) => {
        let fieldset_div = Object.assign(document.createElement("div"), {
            className: "nice-form-group"
        });
        fieldset_div.append(
            Object.assign(document.createElement("input"), {
                className: "option",
                type: input_type,
                name: `${input_type}${idx}`,
                id: `q${idx}-${i}`
            }),
            Object.assign(document.createElement("label"), {
                for: `q${idx}-${i}`,
                innerHTML: v.charAt(0) === '*' ? v.slice(1) : v
            })
        );
        fieldset.append(fieldset_div);
    });

    section.append(div, h2, fieldset);

    return section;
}
